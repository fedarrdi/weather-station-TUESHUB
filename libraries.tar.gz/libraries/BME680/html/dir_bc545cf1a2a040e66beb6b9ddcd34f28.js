var dir_bc545cf1a2a040e66beb6b9ddcd34f28 =
[
    [ ".SoftSPIDemo.vsarduino.h", "_8_soft_s_p_i_demo_8vsarduino_8h_source.html", null ]
];