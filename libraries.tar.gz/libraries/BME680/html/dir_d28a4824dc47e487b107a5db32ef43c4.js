var dir_d28a4824dc47e487b107a5db32ef43c4 =
[
    [ "I2CDemo", "dir_c8c4b843389cbcdb9f579b48d06636fb.html", "dir_c8c4b843389cbcdb9f579b48d06636fb" ],
    [ "SoftSPIDemo", "dir_936da4fe4f1c8ff2d9dbf7c36bedb24d.html", "dir_936da4fe4f1c8ff2d9dbf7c36bedb24d" ],
    [ "SPIDemo", "dir_286f81c20211d9226c7259ab1d3cdc1f.html", "dir_286f81c20211d9226c7259ab1d3cdc1f" ]
];