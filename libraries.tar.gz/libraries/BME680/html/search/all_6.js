var searchData=
[
  ['oversamplingtypes',['oversamplingTypes',['../_zanshin___b_m_e680_8h.html#a5833bdd04da4d5224e3e2c4435e05620',1,'Zanshin_BME680.h']]]
];
