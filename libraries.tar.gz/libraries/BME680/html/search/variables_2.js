var searchData=
[
  ['serial_5fspeed',['SERIAL_SPEED',['../_i2_c_demo_8ino.html#adc8430dea1bce949f10d9708742cca34',1,'I2CDemo.ino']]],
  ['spi_5fhertz',['SPI_HERTZ',['../_zanshin___b_m_e680_8h.html#a480e3ae01b1b51b0a1cdee53a8ccf866',1,'Zanshin_BME680.h']]]
];
