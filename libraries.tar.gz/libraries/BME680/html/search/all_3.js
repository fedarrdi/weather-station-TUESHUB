var searchData=
[
  ['getsensordata',['getSensorData',['../class_b_m_e680___class.html#af0254182c826decbf2122375de32b62f',1,'BME680_Class']]]
];
