ClosedCube Arduino Library for
ClosedCube OPT3001 Digital Ambient Light Sensor (ALS) with High Precision Human Eye Response Breakout 
=====================================================================================================

This is breakout board for [Texas Instruments OPT3001](http://www.ti.com/product/OPT3001) Digital Ambient Light Sensor (ALS) Sensor

[![](https://github.com/closedcube/ClosedCube_OPT3001_Arduino/blob/master/images/B060_OPT3001_Pic1.jpg)](https://www.tindie.com/stores/closedcube/)
[![](https://github.com/closedcube/ClosedCube_OPT3001_Arduino/blob/master/images/B060_OPT3001_Pic2.jpg)](https://www.tindie.com/stores/closedcube/)




